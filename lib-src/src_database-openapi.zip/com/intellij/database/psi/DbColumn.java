package com.intellij.database.psi;

import com.intellij.database.model.PsiColumn;

/**
 * @author Gregory.Shrago
 */
public interface DbColumn extends DbElement, PsiColumn {

  DbTable getDbParent();

  @Override
  DbTable getTable();
}
