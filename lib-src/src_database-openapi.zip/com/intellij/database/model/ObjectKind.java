/*
 * Copyright 2000-2015 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.database.model;

import com.intellij.util.containers.hash.LinkedHashMap;
import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static java.lang.String.format;

/**
 * Kind o database object.
 * @author Leonid Bushuev from JetBrains
 */
public class ObjectKind implements Comparable<ObjectKind> {

  public static final ObjectKind NONE             = new ObjectKind("NONE"             , 0);
  public static final ObjectKind ROOT             = new ObjectKind("ROOT"             , 1);
  public static final ObjectKind DATABASE         = new ObjectKind("DATABASE"         , 2);
  public static final ObjectKind SCHEMA           = new ObjectKind("SCHEMA"           , 3);
  public static final ObjectKind SEQUENCE         = new ObjectKind("SEQUENCE"         , 4);
  public static final ObjectKind CLUSTER          = new ObjectKind("CLUSTER"          , 5);
  public static final ObjectKind OBJECT_TYPE      = new ObjectKind("OBJECT TYPE"      , 6);
  public static final ObjectKind COLLECTION_TYPE  = new ObjectKind("COLLECTION TYPE"  , 7);
  public static final ObjectKind TABLE            = new ObjectKind("TABLE"            , 8);
  public static final ObjectKind MAT_VIEW         = new ObjectKind("MATERIALIZED VIEW", 9);
  public static final ObjectKind VIEW             = new ObjectKind("VIEW"             , 10);
  public static final ObjectKind PACKAGE          = new ObjectKind("PACKAGE"          , 11);
  public static final ObjectKind BODY             = new ObjectKind("BODY"             , 12);
  public static final ObjectKind TABLE_TYPE       = new ObjectKind("TABLE TYPE"       , 13);
  public static final ObjectKind ALIAS_TYPE       = new ObjectKind("ALIAS TYPE"       , 14);
  public static final ObjectKind ROUTINE          = new ObjectKind("ROUTINE"          , 15);
  public static final ObjectKind OPERATOR         = new ObjectKind("OPERATOR"         , 16);
  public static final ObjectKind OBJECT_ATTRIBUTE = new ObjectKind("OBJECT ATTRIBUTE" , 17);
  public static final ObjectKind COLUMN           = new ObjectKind("COLUMN"           , 18);
  public static final ObjectKind INDEX            = new ObjectKind("INDEX"            , 19);
  public static final ObjectKind KEY              = new ObjectKind("KEY"              , 20);
  public static final ObjectKind FOREIGN_KEY      = new ObjectKind("FOREIGN KEY"      , 21);
  public static final ObjectKind CHECK            = new ObjectKind("CHECK"            , 22);
  public static final ObjectKind RULE             = new ObjectKind("RULE"             , 23);
  public static final ObjectKind TRIGGER          = new ObjectKind("TRIGGER"          , 24);
  public static final ObjectKind ARGUMENT         = new ObjectKind("ARGUMENT"         , 25);
  public static final ObjectKind VARIABLE         = new ObjectKind("VARIABLE"         , 26);
  public static final ObjectKind COMMENT          = new ObjectKind("COMMENT"          , 27);
  public static final ObjectKind SYNONYM          = new ObjectKind("SYNONYM"          , 28);
  public static final ObjectKind DB_LINK          = new ObjectKind("DBLINK"           , 29);
  public static final ObjectKind UNKNOWN_OBJECT   = new ObjectKind("UNKNOWN OBJECT"   , Integer.MAX_VALUE);

  private final String myName;
  private final int myOrderNum;

  private static final AtomicInteger ourOrderNumCounter = new AtomicInteger(100);

  public ObjectKind(@NotNull String name) {
    this(name, ourOrderNumCounter.incrementAndGet());
  }

  private ObjectKind(@NotNull String name, int orderNum) {
    assert name.length() > 0;
    assert orderNum >= 0;
    this.myName = name;
    this.myOrderNum = orderNum;
  }

  public String name() {
    return myName;
  }

  /**
   * Returns the formal code, that can be used to write it into a file.
   * This code also XML-friendly, starts with a letter and can contain
   * letters, digits and dashes.
   * @return the formal code.
   */
  public String code() {
    return myName.toLowerCase(Locale.ENGLISH).replace(' ','-');
  }

  /**
   * Returns the order number influences on order of this kind of elements in the script.
   * @return non-negative integer order number.
   */
  public int getOrder() {
    return myOrderNum;
  }

  @Override
  public String toString() {
    return code();
  }

  @Override
  public int compareTo(@NotNull ObjectKind that) {
    if (this == that) return 0;
    if (this.myOrderNum < that.myOrderNum) return -1;
    if (this.myOrderNum > that.myOrderNum) return +1;
    throw new IllegalStateException(format("Uncomparable object kinds: %s and %s", this.code(), that.code()));
  }

  public static final Map<String,ObjectKind> ourKinds;

  static {
    ObjectKind[] theKinds = {
      NONE            ,
      ROOT            ,
      DATABASE        ,
      SCHEMA          ,
      SEQUENCE        ,
      CLUSTER         ,
      TABLE           ,
      MAT_VIEW        ,
      VIEW            ,
      OBJECT_TYPE     ,
      COLLECTION_TYPE ,
      PACKAGE         ,
      BODY            ,
      TABLE_TYPE      ,
      ALIAS_TYPE      ,
      ROUTINE         ,
      OPERATOR        ,
      OBJECT_ATTRIBUTE,
      COLUMN          ,
      INDEX           ,
      KEY             ,
      FOREIGN_KEY     ,
      CHECK           ,
      RULE            ,
      TRIGGER         ,
      ARGUMENT        ,
      VARIABLE        ,
      COMMENT         ,
      SYNONYM         ,
      DB_LINK         ,
      UNKNOWN_OBJECT  ,
    };
    LinkedHashMap<String,ObjectKind> m = new LinkedHashMap<>(40);
    for (ObjectKind kind : theKinds) m.put(kind.code(), kind);
    ourKinds = Collections.unmodifiableMap(m);
  }

}
