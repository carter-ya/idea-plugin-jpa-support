package com.intellij.sql.psi;

import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * @author Gregory.Shrago
 */
public interface SqlAsExpression extends SqlExpression, SqlDefinition {
  @NotNull
  SqlIdentifier getNameElement();

  @NotNull
  SqlExpression getExpression();

  @NotNull
  List<SqlColumnAliasDefinition> getColumnAliasList();
}
