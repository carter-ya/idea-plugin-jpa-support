package com.intellij.sql.psi;

import com.intellij.util.ArrayFactory;
import org.jetbrains.annotations.NotNull;

/**
 * @author Gregory.Shrago
 */
public interface SqlColumnAliasDefinition extends SqlDefinition, SqlNameElement{
  SqlColumnAliasDefinition[] EMPTY_ARRAY = new SqlColumnAliasDefinition[0];
  ArrayFactory<SqlColumnAliasDefinition> ARRAY_FACTORY = count -> count == 0 ? EMPTY_ARRAY : new SqlColumnAliasDefinition[count];
}
