package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlCreateTablespaceStatement extends SqlCreateStatement {
}
