package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlWhenClause extends SqlQueryClause {
}