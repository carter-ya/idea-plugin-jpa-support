package com.intellij.sql.psi;

import com.intellij.psi.PsiLanguageInjectionHost;

/**
 * @author Gregory.Shrago
 */
public interface SqlStringLiteralExpression extends SqlLiteralExpression, PsiLanguageInjectionHost {
}
