package com.intellij.sql.psi;

/**
 * @author Alexey Chmutov
 */
public interface SqlRenameToClause extends SqlClause, SqlSynonymDefinition {
}